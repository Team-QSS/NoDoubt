/*
 * Copyright LWJGL. All rights reserved.
 * License terms: https://www.lwjgl.org/license
 * MACHINE GENERATED FILE, DO NOT EDIT
 */

/** Contains bindings to native APIs specific to the Mac OS X operating system. */
package org.lwjgl.system.macosx;

